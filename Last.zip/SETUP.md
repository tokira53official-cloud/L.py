# PrimeCloud Billing — Updated

## Included
- Normal registration with no SMTP/email verification.
- SMTP configuration and verification flow removed from Admin Settings and registration.
- Admin can create users directly.
- Admin can create/edit plans.
- Built-in plan categories: RDP, Minecraft Hosting, VPS Hosting, Web Hosting, Game Hosting, Discord Bot Hosting, Other.
- Explicit IN STOCK / OUT OF STOCK plan control.
- Out-of-stock plans cannot be ordered and show an out-of-stock message.
- Redeem page simplified; copy button removed.
- Redeem-code admin form clearly describes percentage discount, fixed discount, wallet credit, usage limits and expiry.
- Orders support Pending/Active/Processing/Completed/Failed/Warned/Cancelled/Refunded statuses.
- Card checkout is represented as a secure gateway flow; raw card numbers/CVV are not collected or stored by this app.
- Existing Discord/Google OAuth, wallet, tickets and admin features preserved.

## Start
```bash
pip install -r requirements.txt
python website.py
```

Default development URL: `http://YOUR_SERVER:4040`

## Payment security
For card payments, connect a PCI-compliant hosted payment provider (for example, a provider's hosted checkout/payment page). The PrimeCloud application should receive only gateway/order status and transaction identifiers—not full card numbers, CVV or other raw card secrets.

For identity verification/KYC, use a compliant third-party KYC provider. Do not collect/store Aadhaar images/numbers or full payment-card details in the PrimeCloud admin panel.

## Discord / Google login
Configure OAuth credentials in **Admin → Settings**.

Callback paths:
- `https://YOUR_DOMAIN/oauth/discord/callback`
- `https://YOUR_DOMAIN/oauth/google/callback`

Put the exact public URLs into the provider dashboard and PrimeCloud Admin → Settings.

Authlib is included in `requirements.txt`.
