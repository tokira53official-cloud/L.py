import os, sqlite3, secrets, uuid, hashlib, ssl
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort, jsonify, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
try:
    from authlib.integrations.flask_client import OAuth
except ImportError:
    OAuth = None

BASE = Path(__file__).resolve().parent
DB = BASE / "primecloud.db"
UPLOADS = BASE / "uploads"
UPLOADS.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY") or "dev-change-this-secret"
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
ALLOWED = {"png","jpg","jpeg","webp","gif","pdf"}

BRAND_LOGO = "https://cdn.discordapp.com/icons/1541076796336767047/41cea41efeedbc57359f211439003c63.webp?size=2048"
UPI_ID = "tokira53official@okicici"
UPI_QR = "https://cdn.discordapp.com/attachments/1541197943305015347/1545857666385969253/GooglePay_QR.png?ex=6abb5564&is=6aba03e4&hm=336f9ee989abe3564bbdcca05f48ae4b908479d1e6e7ff3547448f822da4b61d&"

oauth = OAuth(app) if OAuth else None

def setting(key, default=""):
    row = q("SELECT value FROM settings WHERE key=?", (key,), True)
    return row["value"] if row and row["value"] is not None else default

def set_setting(key, value):
    q("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

def now():
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def q(sql, params=(), one=False):
    con=db()
    cur=con.execute(sql, params)
    rows=cur.fetchone() if one else cur.fetchall()
    con.commit(); con.close()
    return rows

def init_db():
    con=db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, is_admin INTEGER DEFAULT 0,
      disabled INTEGER DEFAULT 0, referral_code TEXT UNIQUE, first_name TEXT DEFAULT '',
      last_name TEXT DEFAULT '', email_verified INTEGER DEFAULT 0,
      verification_code TEXT, verification_expires TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS plans(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL,
      description TEXT, ram TEXT, cpu TEXT, storage TEXT, price REAL NOT NULL DEFAULT 0,
      billing_period TEXT DEFAULT 'month', image TEXT, stock INTEGER DEFAULT 0, active INTEGER DEFAULT 1,
      created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS orders(
      id INTEGER PRIMARY KEY AUTOINCREMENT, order_code TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL,
      plan_id INTEGER NOT NULL, amount REAL NOT NULL, payment_method TEXT, payment_status TEXT DEFAULT 'Pending Payment',
      order_status TEXT DEFAULT 'Pending Payment', redeem_discount REAL DEFAULT 0, created_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(plan_id) REFERENCES plans(id));
    CREATE TABLE IF NOT EXISTS vps_verifications(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, plan_id INTEGER NOT NULL,
      full_name TEXT NOT NULL, father_name TEXT NOT NULL, age INTEGER, father_age INTEGER,
      phone TEXT NOT NULL, city TEXT NOT NULL, state TEXT NOT NULL, country TEXT DEFAULT 'India',
      intended_use TEXT NOT NULL, traffic_estimate TEXT, abuse_policy INTEGER DEFAULT 0,
      status TEXT DEFAULT 'Pending', admin_note TEXT DEFAULT '', provider_reference TEXT DEFAULT '',
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(plan_id) REFERENCES plans(id));
    CREATE TABLE IF NOT EXISTS payments(
      id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, amount REAL NOT NULL,
      method TEXT, status TEXT DEFAULT 'Pending', transaction_id TEXT, created_at TEXT NOT NULL,
      FOREIGN KEY(order_id) REFERENCES orders(id));
    CREATE TABLE IF NOT EXISTS wallet_transactions(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, amount REAL NOT NULL,
      kind TEXT NOT NULL, reason TEXT, created_at TEXT NOT NULL, admin_id INTEGER,
      FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS redeem_codes(
      id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, reward_type TEXT NOT NULL,
      value REAL NOT NULL, max_uses INTEGER DEFAULT 1, per_user_limit INTEGER DEFAULT 1,
      uses INTEGER DEFAULT 0, expiry TEXT, applicable_product TEXT, active INTEGER DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS redemptions(
      id INTEGER PRIMARY KEY AUTOINCREMENT, code_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
      reward REAL NOT NULL, created_at TEXT NOT NULL, UNIQUE(code_id,user_id),
      FOREIGN KEY(code_id) REFERENCES redeem_codes(id), FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS tickets(
      id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_code TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL,
      subject TEXT NOT NULL, category TEXT, priority TEXT, description TEXT, status TEXT DEFAULT 'Open',
      assigned_to INTEGER, internal_note TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS ticket_messages(
      id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
      message TEXT NOT NULL, attachment TEXT, created_at TEXT NOT NULL,
      FOREIGN KEY(ticket_id) REFERENCES tickets(id));
    CREATE TABLE IF NOT EXISTS notifications(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT, message TEXT,
      type TEXT DEFAULT 'Info', read INTEGER DEFAULT 0, created_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS referrals(
      id INTEGER PRIMARY KEY AUTOINCREMENT, referrer_id INTEGER NOT NULL, referred_id INTEGER NOT NULL,
      reward REAL DEFAULT 0, created_at TEXT NOT NULL, UNIQUE(referrer_id,referred_id));
    CREATE TABLE IF NOT EXISTS invoices(
      id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_code TEXT UNIQUE NOT NULL, order_id INTEGER NOT NULL,
      created_at TEXT NOT NULL, status TEXT DEFAULT 'Issued', FOREIGN KEY(order_id) REFERENCES orders(id));
    CREATE TABLE IF NOT EXISTS announcements(
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, message TEXT NOT NULL,
      type TEXT DEFAULT 'Info', active INTEGER DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS activity_logs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id INTEGER, action TEXT, ip TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
    """)
    # Lightweight migrations for databases created by older PrimeCloud builds.
    plan_cols = {r["name"] for r in con.execute("PRAGMA table_info(plans)").fetchall()}
    if "stock_status" not in plan_cols:
        con.execute("ALTER TABLE plans ADD COLUMN stock_status INTEGER DEFAULT 1")
        con.execute("UPDATE plans SET stock_status=CASE WHEN stock=0 THEN 0 ELSE 1 END")
    cols = {r["name"] for r in con.execute("PRAGMA table_info(users)").fetchall()}
    for name, definition in [
        ("first_name", "TEXT DEFAULT ''"), ("last_name", "TEXT DEFAULT ''"),
        ("email_verified", "INTEGER DEFAULT 1"), ("verification_code", "TEXT"),
        ("verification_expires", "TEXT")
    ]:
        if name not in cols:
            con.execute(f"ALTER TABLE users ADD COLUMN {name} {definition}")
    con.execute("UPDATE users SET email_verified=1 WHERE email_verified=0")
    admin_user=os.getenv("ADMIN_USERNAME","admin")
    admin_email=os.getenv("ADMIN_EMAIL","admin@primecloud.local")
    admin_pass=os.getenv("ADMIN_PASSWORD")
    if not admin_pass:
        admin_pass="PrimeCloud@123!"
        print("WARNING: ADMIN_PASSWORD is not set. Temporary development admin created.")
        print("Username:", admin_user, "Password:", admin_pass)
        print("Set ADMIN_PASSWORD before production.")
    existing=con.execute("SELECT id FROM users WHERE username=?", (admin_user,)).fetchone()
    if not existing:
        con.execute("INSERT INTO users(username,email,password_hash,is_admin,referral_code,created_at) VALUES(?,?,?,?,?,?)",
                    (admin_user,admin_email,generate_password_hash(admin_pass),1,"PRIME-"+admin_user.upper(),now()))
    if not con.execute("SELECT id FROM plans LIMIT 1").fetchone():
        plans=[
          ("2GB Minecraft","Minecraft Hosting","Starter Minecraft server","2 GB","50% CPU","10 GB",20,"month","",25),
          ("4GB Minecraft","Minecraft Hosting","Balanced Minecraft server","4 GB","100% CPU","20 GB",40,"month","",20),
          ("6GB Minecraft","Minecraft Hosting","Power Minecraft server","6 GB","125% CPU","25 GB",80,"month","",15),
          ("8GB Minecraft","Minecraft Hosting","High performance Minecraft server","8 GB","200% CPU","30 GB",100,"month","",10),
          ("12GB Minecraft","Minecraft Hosting","Large Minecraft server","12 GB","300% CPU","60 GB",200,"month","",5),
          ("Ubuntu VPS 4GB","VPS Hosting","Ubuntu cloud VPS","4 GB","2 vCPU","40 GB",250,"month","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSkizv018a9GKvz9lWwo34F0_R5u4HXFcKSr_rS-enZQ&s=10",10),
          ("Ubuntu VPS 8GB","VPS Hosting","Ubuntu cloud VPS","8 GB","4 vCPU","80 GB",450,"month","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSkizv018a9GKvz9lWwo34F0_R5u4HXFcKSr_rS-enZQ&s=10",5)]
        con.executemany("INSERT INTO plans(name,category,description,ram,cpu,storage,price,billing_period,image,stock,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                        [p+(now(),) for p in plans])
    defaults = {
        "brand_logo": BRAND_LOGO, "upi_id": UPI_ID, "upi_qr": UPI_QR,
        "discord_client_id": os.getenv("DISCORD_CLIENT_ID",""), "discord_client_secret": os.getenv("DISCORD_CLIENT_SECRET",""),
        "discord_redirect_uri": os.getenv("DISCORD_REDIRECT_URI",""),
        "google_client_id": os.getenv("GOOGLE_CLIENT_ID",""), "google_client_secret": os.getenv("GOOGLE_CLIENT_SECRET",""),
        "google_redirect_uri": os.getenv("GOOGLE_REDIRECT_URI","")
    }
    for k,v in defaults.items():
        con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)",(k,v))
    con.commit(); con.close()

def current_user():
    uid=session.get("uid")
    return q("SELECT * FROM users WHERE id=?", (uid,), True) if uid else None

@app.context_processor
def ctx():
    u=current_user()
    unread=0
    if u: unread=q("SELECT COUNT(*) c FROM notifications WHERE user_id=? AND read=0",(u["id"],),True)["c"]
    return {"user":u,"unread":unread,"brand_logo":"https://i.ibb.co/qhQxkbm/fc27d6b324431b73e38c600ecb538f09.gif"}

def login_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not current_user(): flash("Please login first.","warning"); return redirect(url_for("login", next=request.path))
        return f(*a,**kw)
    return w

def admin_required(f):
    @wraps(f)
    def w(*a,**kw):
        u=current_user()
        if not u or not u["is_admin"]: abort(403)
        return f(*a,**kw)
    return w

def log(action, actor=None):
    q("INSERT INTO activity_logs(actor_id,action,ip,created_at) VALUES(?,?,?,?)",(actor,action,request.remote_addr,now()))

def notify(uid,title,message,typ="Info"):
    q("INSERT INTO notifications(user_id,title,message,type,created_at) VALUES(?,?,?,?,?)",(uid,title,message,typ,now()))

def wallet_balance(uid):
    r=q("SELECT COALESCE(SUM(amount),0) b FROM wallet_transactions WHERE user_id=?",(uid,),True)
    return float(r["b"])

def save_upload(file):
    if not file or not file.filename: return None
    ext=file.filename.rsplit(".",1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED: raise ValueError("Unsupported file type.")
    name=f"{uuid.uuid4().hex}.{ext}"
    file.save(UPLOADS/name); return name

@app.context_processor
def inject_globals():
    u = current_user()
    return {
        "user": u,
        "brand_logo": setting("brand_logo", BRAND_LOGO),
        "upi_id": setting("upi_id", UPI_ID),
        "upi_qr": setting("upi_qr", UPI_QR)
    }

@app.route("/")
def home():
    plans=q("SELECT * FROM plans WHERE active=1 ORDER BY price LIMIT 6")
    anns=q("SELECT * FROM announcements WHERE active=1 ORDER BY id DESC LIMIT 3")
    return render_template("index.html",plans=plans,announcements=anns)

@app.route("/plans")
def plans():
    category=request.args.get("category")
    rows=q("SELECT * FROM plans WHERE active=1 "+("AND category=? " if category else "")+"ORDER BY price",(category,) if category else ())
    return render_template("plans.html",plans=rows,categories=["RDP","Minecraft Hosting","VPS Hosting","Web Hosting","Game Hosting","Discord Bot Hosting","Other"])

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="POST":
        username=request.form.get("username","").strip()
        email=request.form.get("email","").strip().lower()
        first_name=request.form.get("first_name","").strip()
        last_name=request.form.get("last_name","").strip()
        password=request.form.get("password","")
        confirm=request.form.get("confirm","")
        if not username or not email or len(password)<8:
            flash("Use a username, valid email and password of at least 8 characters.","danger")
        elif password!=confirm:
            flash("Passwords do not match.","danger")
        else:
            try:
                ref=request.args.get("ref") or request.form.get("ref")
                code="PRIME-"+re.sub(r"[^A-Za-z0-9]","",username).upper()
                q("""INSERT INTO users(username,email,password_hash,referral_code,first_name,last_name,
                     email_verified,created_at) VALUES(?,?,?,?,?,?,1,?)""",
                  (username,email,generate_password_hash(password),code,first_name,last_name,now()))
                u=q("SELECT * FROM users WHERE username=?",(username,),True)
                if ref:
                    r=q("SELECT * FROM users WHERE referral_code=?",(ref.upper(),),True)
                    if r and r["id"]!=u["id"]:
                        q("INSERT OR IGNORE INTO referrals(referrer_id,referred_id,reward,created_at) VALUES(?,?,?,?)",(r["id"],u["id"],0,now()))
                flash("Account created successfully. You can login now.","success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Username or email already exists.","danger")
    return render_template("register.html",ref=request.args.get("ref",""))

@app.route("/verify-email",methods=["GET"])
def verify_email():
    return redirect(url_for("login"))

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        ident=request.form.get("identity","").strip()
        u=q("SELECT * FROM users WHERE username=? OR email=?",(ident,ident.lower()),True)
        if u and not u["disabled"] and check_password_hash(u["password_hash"],request.form.get("password","")):
            session.clear(); session["uid"]=u["id"]; log("User logged in",u["id"]); return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Invalid credentials or disabled account.","danger")
    return render_template("login.html")

def oauth_client(provider):
    if not oauth: return None
    cid=setting(f"{provider}_client_id"); secret=setting(f"{provider}_client_secret")
    if not cid or not secret: return None
    name=f"{provider}_runtime"
    try:
        return oauth.create_client(name)
    except Exception:
        pass
    if provider=="google":
        return oauth.register(name=name, client_id=cid, client_secret=secret,
            server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
            client_kwargs={"scope":"openid email profile"})
    return oauth.register(name=name, client_id=cid, client_secret=secret,
        access_token_url="https://discord.com/api/oauth2/token",
        authorize_url="https://discord.com/api/oauth2/authorize",
        api_base_url="https://discord.com/api/",
        client_kwargs={"scope":"identify email"})

@app.route("/login/<provider>")
def oauth_login(provider):
    if provider not in ("google","discord"):
        return redirect(url_for("login"))
    client=oauth_client(provider)
    redirect_uri=setting(f"{provider}_redirect_uri")
    if not client or not redirect_uri:
        flash(f"{provider.title()} login is not configured by the admin.","warning")
        return redirect(url_for("login"))
    return client.authorize_redirect(redirect_uri)

@app.route("/oauth/<provider>/callback")
def oauth_callback(provider):
    if provider not in ("google","discord"):
        return redirect(url_for("login"))
    client=oauth_client(provider)
    if not client:
        flash("OAuth is not configured.","danger"); return redirect(url_for("login"))
    try:
        token=client.authorize_access_token()
        if provider=="google":
            info=token.get("userinfo") or client.userinfo()
            email=(info.get("email") or "").lower()
            username=info.get("preferred_username") or info.get("name") or email.split("@")[0]
            first=info.get("given_name",""); last=info.get("family_name","")
        else:
            info=client.get("users/@me").json()
            email=(info.get("email") or "").lower()
            username=info.get("username") or email.split("@")[0]
            first=""; last=""
    except Exception as exc:
        print("OAuth callback error:", exc)
        flash("OAuth login failed. Check the provider settings and redirect URI.","danger")
        return redirect(url_for("login"))
    if not email:
        flash("OAuth provider did not return an email address.","danger"); return redirect(url_for("login"))
    u=q("SELECT * FROM users WHERE email=?",(email,),True)
    if not u:
        base=re.sub(r"[^A-Za-z0-9_]","",username)[:24] or "user"
        candidate=base; n=1
        while q("SELECT id FROM users WHERE username=?",(candidate,),True):
            n+=1; candidate=f"{base}{n}"
        ref="PRIME-"+candidate.upper()
        q("""INSERT INTO users(username,email,password_hash,is_admin,disabled,referral_code,first_name,last_name,
             email_verified,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)""",
          (candidate,email,generate_password_hash(secrets.token_urlsafe(24)),0,0,ref,first,last,1,now()))
        u=q("SELECT * FROM users WHERE email=?",(email,),True)
    if u["disabled"]:
        flash("This account is disabled.","danger"); return redirect(url_for("login"))
    session.clear(); session["uid"]=u["id"]; log(f"{provider.title()} OAuth login",u["id"])
    return redirect(url_for("dashboard"))

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("home"))

@app.route("/forgot-password",methods=["GET","POST"])
def forgot():
    if request.method=="POST": flash("Password-reset architecture is ready. Please contact an administrator to reset your password.","info")
    return render_template("forgot.html")

@app.route("/account",methods=["GET","POST"])
@login_required
def account():
    u=current_user()
    if request.method=="POST":
        username=request.form.get("username",u["username"]).strip()
        email=request.form.get("email",u["email"]).strip().lower()
        first_name=request.form.get("first_name","").strip()
        last_name=request.form.get("last_name","").strip()
        password=request.form.get("password","")
        try:
            if not username or not email: raise ValueError("Username and email are required.")
            if password:
                if len(password)<8: raise ValueError("New password must be at least 8 characters.")
                q("UPDATE users SET username=?,email=?,first_name=?,last_name=?,password_hash=? WHERE id=?",
                  (username,email,first_name,last_name,generate_password_hash(password),u["id"]))
            else:
                q("UPDATE users SET username=?,email=?,first_name=?,last_name=? WHERE id=?",
                  (username,email,first_name,last_name,u["id"]))
            flash("Account details updated.","success")
        except (sqlite3.IntegrityError, ValueError) as exc:
            flash("Username/email is already in use." if isinstance(exc,sqlite3.IntegrityError) else str(exc),"danger")
    return render_template("account.html",account=q("SELECT * FROM users WHERE id=?",(u["id"],),True))

@app.route("/dashboard")
@login_required
def dashboard():
    u=current_user()
    orders=q("""SELECT o.*,p.name plan_name FROM orders o JOIN plans p ON p.id=o.plan_id
               WHERE o.user_id=? ORDER BY o.id DESC LIMIT 5""",(u["id"],))
    tickets=q("SELECT * FROM tickets WHERE user_id=? AND status IN ('Open','Pending')",(u["id"],))
    return render_template("dashboard.html",balance=wallet_balance(u["id"]),orders=orders,tickets=tickets,
                          announcements=q("SELECT * FROM announcements WHERE active=1 ORDER BY id DESC LIMIT 3"))

@app.route("/orders")
@login_required
def orders():
    rows=q("SELECT o.*,p.name plan_name FROM orders o JOIN plans p ON p.id=o.plan_id WHERE o.user_id=? ORDER BY o.id DESC",(current_user()["id"],))
    return render_template("orders.html",orders=rows)

@app.route("/checkout/<int:plan_id>",methods=["GET","POST"])
@login_required
def checkout(plan_id):
    plan=q("SELECT * FROM plans WHERE id=? AND active=1",(plan_id,),True)
    if not plan: abort(404)
    if not plan["stock_status"] or plan["stock"] == 0:
        flash("This plan is currently out of stock.","danger")
        return redirect(url_for("plans"))
    is_vps = "vps" in (plan["category"] or "").lower()
    existing_kyc=q("SELECT * FROM vps_verifications WHERE user_id=? AND plan_id=? ORDER BY id DESC",(current_user()["id"],plan_id),True) if is_vps else None
    if request.method=="POST" and is_vps and not existing_kyc or (request.method=="POST" and is_vps and existing_kyc and existing_kyc["status"] != "Verified"):
        # VPS verification stores only limited account/identity information. Raw Aadhaar/card data is never stored.
        required=["full_name","father_name","age","father_age","phone","city","state","intended_use"]
        if not all(request.form.get(x,"").strip() for x in required) or request.form.get("abuse_policy") != "1":
            flash("Please complete VPS verification and accept the abuse policy before payment.","danger")
            return render_template("checkout.html",plan=plan,amount=plan["price"],is_vps=True,kyc=existing_kyc,verification_required=True)
        try:
            age=int(request.form.get("age")); father_age=int(request.form.get("father_age"))
            if age < 13 or age > 100 or father_age < 18 or father_age > 120: raise ValueError
        except ValueError:
            flash("Please enter valid ages.","danger")
            return render_template("checkout.html",plan=plan,amount=plan["price"],is_vps=True,kyc=existing_kyc,verification_required=True)
        if existing_kyc:
            q("UPDATE vps_verifications SET full_name=?,father_name=?,age=?,father_age=?,phone=?,city=?,state=?,country=?,intended_use=?,traffic_estimate=?,abuse_policy=1,status='Pending',updated_at=? WHERE id=?",
              (request.form["full_name"].strip(),request.form["father_name"].strip(),age,father_age,request.form["phone"].strip(),request.form["city"].strip(),request.form["state"].strip(),request.form.get("country","India").strip(),request.form["intended_use"].strip(),request.form.get("traffic_estimate","").strip(),now(),existing_kyc["id"]))
        else:
            q("INSERT INTO vps_verifications(user_id,plan_id,full_name,father_name,age,father_age,phone,city,state,country,intended_use,traffic_estimate,abuse_policy,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?, 'Pending',?,?)",
              (current_user()["id"],plan_id,request.form["full_name"].strip(),request.form["father_name"].strip(),age,father_age,request.form["phone"].strip(),request.form["city"].strip(),request.form["state"].strip(),request.form.get("country","India").strip(),request.form["intended_use"].strip(),request.form.get("traffic_estimate","").strip(),1,now(),now()))
        flash("VPS verification submitted. Admin review is required before payment.","success")
        return redirect(url_for("checkout",plan_id=plan_id))
    existing_kyc=q("SELECT * FROM vps_verifications WHERE user_id=? AND plan_id=? ORDER BY id DESC",(current_user()["id"],plan_id),True) if is_vps else None
    if is_vps and (not existing_kyc or existing_kyc["status"] != "Verified"):
        return render_template("checkout.html",plan=plan,amount=plan["price"],is_vps=True,kyc=existing_kyc,verification_required=True)
    discount=0
    amount=plan["price"]
    if request.method=="POST":
        method=request.form.get("payment_method","Card Gateway")
        code=request.form.get("redeem_code","").strip().upper()
        if code:
            rc=q("SELECT * FROM redeem_codes WHERE code=? AND active=1",(code,),True)
            if not rc: flash("Invalid or disabled redeem code.","danger"); return render_template("checkout.html",plan=plan,amount=amount,is_vps=is_vps,kyc=existing_kyc)
            if rc["expiry"] and rc["expiry"] < now(): flash("Redeem code expired.","danger"); return render_template("checkout.html",plan=plan,amount=amount,is_vps=is_vps,kyc=existing_kyc)
            used=q("SELECT COUNT(*) c FROM redemptions WHERE code_id=? AND user_id=?",(rc["id"],current_user()["id"]),True)["c"]
            if used>=rc["per_user_limit"] or rc["uses"]>=rc["max_uses"]: flash("Redeem code usage limit reached.","danger"); return render_template("checkout.html",plan=plan,amount=amount,is_vps=is_vps,kyc=existing_kyc)
            if rc["reward_type"] in ("Percentage Discount","Discount %"): discount=round(plan["price"]*rc["value"]/100,2)
            elif rc["reward_type"] in ("Product Discount","Fixed Discount"): discount=min(plan["price"],rc["value"])
            amount=round(max(0,plan["price"]-discount),2)
        # Stock is decremented atomically only after all checks pass.
        cur=db(); cur.execute("UPDATE plans SET stock=stock-1 WHERE id=? AND stock>0 AND stock_status=1",(plan_id,)); changed=cur.total_changes; cur.commit(); cur.close()
        if not changed:
            flash("This plan just went out of stock.","danger"); return redirect(url_for("plans"))
        order_code=f"PC-{uuid.uuid4().hex[:10].upper()}"
        payment_status="Pending Payment" if method != "Wallet" else "Paid"
        order_status="Pending" if method != "Wallet" else "Paid"
        q("INSERT INTO orders(order_code,user_id,plan_id,amount,payment_method,payment_status,order_status,redeem_discount,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
          (order_code,current_user()["id"],plan_id,amount,method,payment_status,order_status,discount,now()))
        order=q("SELECT * FROM orders WHERE order_code=?",(order_code,),True)
        q("INSERT INTO payments(order_id,amount,method,status,created_at) VALUES(?,?,?,?,?)",(order["id"],amount,method,payment_status,now()))
        if code:
            q("UPDATE redeem_codes SET uses=uses+1 WHERE id=?",(rc["id"],))
            q("INSERT OR IGNORE INTO redemptions(code_id,user_id,reward,created_at) VALUES(?,?,?,?)",(rc["id"],current_user()["id"],discount,now()))
        notify(current_user()["id"],"Order Created",f"Order #{order_code} is {order_status}.","Info")
        log(f"Created order #{order_code}",current_user()["id"])
        return redirect(url_for("order_detail",order_id=order["id"]))
    return render_template("checkout.html",plan=plan,amount=amount,is_vps=is_vps,kyc=existing_kyc)

@app.route("/order/<int:order_id>")
@login_required
def order_detail(order_id):
    o=q("""SELECT o.*,p.name plan_name,p.ram,p.cpu,p.storage,u.username,u.email
           FROM orders o JOIN plans p ON p.id=o.plan_id JOIN users u ON u.id=o.user_id
           WHERE o.id=?""",(order_id,),True)
    if not o or (o["user_id"]!=current_user()["id"] and not current_user()["is_admin"]): abort(404)
    inv=q("SELECT * FROM invoices WHERE order_id=?",(order_id,),True)
    if o["payment_status"]=="Paid" and not inv:
        q("INSERT INTO invoices(invoice_code,order_id,created_at) VALUES(?,?,?)",(f"INV-{o['order_code']}",order_id,now()))
        inv=q("SELECT * FROM invoices WHERE order_id=?",(order_id,),True)
    return render_template("order_detail.html",order=o,invoice=inv)

@app.route("/invoice/<int:invoice_id>")
@login_required
def invoice(invoice_id):
    inv=q("""SELECT i.*,o.order_code,o.amount,o.payment_method,o.payment_status,o.created_at,
             p.name plan_name,u.username,u.email FROM invoices i JOIN orders o ON o.id=i.order_id
             JOIN plans p ON p.id=o.plan_id JOIN users u ON u.id=o.user_id WHERE i.id=?""",(invoice_id,),True)
    if not inv or (inv["username"]!=current_user()["username"] and not current_user()["is_admin"]): abort(403)
    return render_template("invoice.html",invoice=inv)

@app.route("/wallet")
@login_required
def wallet():
    u=current_user()
    return render_template("wallet.html",balance=wallet_balance(u["id"]),transactions=q("SELECT * FROM wallet_transactions WHERE user_id=? ORDER BY id DESC",(u["id"],)))

@app.route("/redeem",methods=["GET","POST"])
@login_required
def redeem():
    u=current_user()
    if request.method=="POST":
        code=request.form.get("code","").strip().upper()
        rc=q("SELECT * FROM redeem_codes WHERE code=?",(code,),True)
        if not rc or not rc["active"]: flash("Invalid or disabled code.","danger")
        elif rc["expiry"] and rc["expiry"] < now(): flash("This code has expired.","danger")
        elif rc["uses"]>=rc["max_uses"]: flash("This code has reached its maximum uses.","danger")
        elif q("SELECT id FROM redemptions WHERE code_id=? AND user_id=?",(rc["id"],u["id"]),True): flash("You already redeemed this code.","danger")
        else:
            reward=rc["value"]
            if rc["reward_type"]=="Fixed Wallet Credit":
                q("INSERT INTO wallet_transactions(user_id,amount,kind,reason,created_at) VALUES(?,?,?,?,?)",(u["id"],reward,"Credit","Redeem "+code,now()))
            q("INSERT INTO redemptions(code_id,user_id,reward,created_at) VALUES(?,?,?,?)",(rc["id"],u["id"],reward,now()))
            q("UPDATE redeem_codes SET uses=uses+1 WHERE id=?",(rc["id"],))
            notify(u["id"],"Redeem Successful",f"Code {code} redeemed successfully.","Success"); log(f"Redeemed code {code}",u["id"])
            flash("Code redeemed successfully.","success")
    history=q("""SELECT r.*,c.code,c.reward_type FROM redemptions r JOIN redeem_codes c ON c.id=r.code_id
                 WHERE r.user_id=? ORDER BY r.id DESC""",(u["id"],))
    return render_template("redeem.html",history=history)

@app.route("/notifications")
@login_required
def notifications():
    u=current_user()
    q("UPDATE notifications SET read=1 WHERE user_id=?",(u["id"],))
    return render_template("notifications.html",notifications=q("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC",(u["id"],)))

@app.route("/support",methods=["GET","POST"])
@login_required
def support():
    if request.method=="POST":
        try: attachment=save_upload(request.files.get("attachment"))
        except ValueError as e: flash(str(e),"danger"); return redirect(url_for("support"))
        u=current_user(); code=f"PC-{10000+q('SELECT COALESCE(MAX(id),0)+1 n FROM tickets',(),True)['n']}"
        q("""INSERT INTO tickets(ticket_code,user_id,subject,category,priority,description,status,created_at,updated_at)
             VALUES(?,?,?,?,?,?,?,?,?)""",(code,u["id"],request.form.get("subject",""),request.form.get("category","Other"),
             request.form.get("priority","Normal"),request.form.get("description",""),"Open",now(),now()))
        t=q("SELECT * FROM tickets WHERE ticket_code=?",(code,),True)
        q("INSERT INTO ticket_messages(ticket_id,user_id,message,attachment,created_at) VALUES(?,?,?,?,?)",(t["id"],u["id"],t["description"],attachment,now()))
        log(f"Created ticket #{code}",u["id"]); flash(f"Ticket #{code} created.","success"); return redirect(url_for("ticket",ticket_id=t["id"]))
    return render_template("support.html",tickets=q("SELECT * FROM tickets WHERE user_id=? ORDER BY id DESC",(current_user()["id"],)))

@app.route("/ticket/<int:ticket_id>",methods=["GET","POST"])
@login_required
def ticket(ticket_id):
    t=q("SELECT * FROM tickets WHERE id=?",(ticket_id,),True)
    u=current_user()
    if not t or (t["user_id"]!=u["id"] and not u["is_admin"]): abort(404)
    if request.method=="POST":
        try: attachment=save_upload(request.files.get("attachment"))
        except ValueError as e: flash(str(e),"danger"); return redirect(url_for("ticket",ticket_id=ticket_id))
        msg=request.form.get("message","").strip()
        if msg:
            q("INSERT INTO ticket_messages(ticket_id,user_id,message,attachment,created_at) VALUES(?,?,?,?,?)",(ticket_id,u["id"],msg,attachment,now()))
            q("UPDATE tickets SET updated_at=?,status=? WHERE id=?",(now(),"Open" if u["id"]==t["user_id"] else t["status"],ticket_id))
            if u["id"]!=t["user_id"]: notify(t["user_id"],"Ticket Reply",f"New reply on {t['ticket_code']}.","Info")
            flash("Message sent.","success")
        return redirect(url_for("ticket",ticket_id=ticket_id))
    return render_template("ticket.html",ticket=t,messages=q("""SELECT m.*,u.username,u.is_admin FROM ticket_messages m JOIN users u ON u.id=m.user_id
                   WHERE m.ticket_id=? ORDER BY m.id""",(ticket_id,)))

@app.route("/uploads/<path:name>")
@login_required
def uploads(name):
    # Access is authenticated; ticket authorization is handled by the UI/routes.
    return send_from_directory(UPLOADS,name)

@app.route("/admin")
@admin_required
def admin():
    stats={
      "users":q("SELECT COUNT(*) c FROM users",(),True)["c"],
      "orders":q("SELECT COUNT(*) c FROM orders",(),True)["c"],
      "revenue":q("SELECT COALESCE(SUM(amount),0) c FROM orders WHERE payment_status='Paid'",(),True)["c"],
      "pending":q("SELECT COUNT(*) c FROM orders WHERE payment_status='Pending Payment'",(),True)["c"],
      "tickets":q("SELECT COUNT(*) c FROM tickets WHERE status IN ('Open','Pending')",(),True)["c"],
      "plans":q("SELECT COUNT(*) c FROM plans WHERE active=1",(),True)["c"],
      "codes":q("SELECT COUNT(*) c FROM redeem_codes WHERE active=1",(),True)["c"]}
    return render_template("admin/dashboard.html",stats=stats)

@app.route("/admin/users")
@admin_required
def admin_users():
    search=request.args.get("q","").strip()
    rows=q("SELECT * FROM users WHERE username LIKE ? OR email LIKE ? ORDER BY id DESC",("%"+search+"%","%"+search+"%"))
    return render_template("admin/users.html",users=rows)

@app.route("/admin/user/create",methods=["POST"])
@admin_required
def admin_user_create():
    username=request.form.get("username","").strip()
    email=request.form.get("email","").strip().lower()
    password=request.form.get("password","")
    is_admin=1 if request.form.get("is_admin")=="1" else 0
    if not username or not email or len(password)<8:
        flash("Username, email and a password of at least 8 characters are required.","danger")
        return redirect(url_for("admin_users"))
    try:
        ref="PRIME-"+re.sub(r"[^A-Za-z0-9]","",username).upper()
        q("""INSERT INTO users(username,email,password_hash,is_admin,disabled,referral_code,email_verified,created_at)
             VALUES(?,?,?,?,0,?,1,?)""",(username,email,generate_password_hash(password),is_admin,ref,now()))
        flash("User created successfully.","success")
        log(f"Admin created user {username}",current_user()["id"])
    except sqlite3.IntegrityError:
        flash("Username or email already exists.","danger")
    return redirect(url_for("admin_users"))

@app.route("/admin/user/<int:uid>/toggle",methods=["POST"])
@admin_required
def admin_toggle_user(uid):
    q("UPDATE users SET disabled=1-disabled WHERE id=?",(uid,)); log(f"Toggled user {uid}",current_user()["id"]); return redirect(url_for("admin_users"))

@app.route("/admin/user/<int:uid>/wallet",methods=["POST"])
@admin_required
def admin_wallet(uid):
    amount=float(request.form.get("amount",0)); kind="Credit" if amount>=0 else "Debit"
    q("INSERT INTO wallet_transactions(user_id,amount,kind,reason,created_at,admin_id) VALUES(?,?,?,?,?,?)",(uid,amount,kind,request.form.get("reason","Admin adjustment"),now(),current_user()["id"]))
    notify(uid,"Wallet Updated",f"Wallet {kind.lower()} of ₹{abs(amount):.2f}.","Info"); log(f"Wallet adjustment for user {uid}: {amount}",current_user()["id"])
    return redirect(url_for("admin_users"))

@app.route("/admin/plans",methods=["GET","POST"])
@admin_required
def admin_plans():
    categories=["RDP","Minecraft Hosting","VPS Hosting","Web Hosting","Game Hosting","Discord Bot Hosting","Other"]
    if request.method=="POST":
        image=request.form.get("image","").strip()
        try: image=image or save_upload(request.files.get("image_file"))
        except ValueError as e: flash(str(e),"danger"); return redirect(url_for("admin_plans"))
        category=request.form.get("category","Other").strip() or "Other"
        stock=int(request.form.get("stock",0))
        stock_status=1 if request.form.get("stock_status")=="1" else 0
        q("""INSERT INTO plans(name,category,description,ram,cpu,storage,price,billing_period,image,stock,stock_status,active,created_at)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",(request.form["name"],category,request.form.get("description",""),request.form.get("ram",""),
             request.form.get("cpu",""),request.form.get("storage",""),float(request.form["price"]),request.form.get("billing_period","month"),
             image or "",stock,stock_status,1,now()))
        log("Admin created plan",current_user()["id"]); flash("Plan created.","success")
    return render_template("admin/plans.html",plans=q("SELECT * FROM plans ORDER BY id DESC"),categories=categories)

@app.route("/admin/plan/<int:pid>/edit",methods=["POST"])
@admin_required
def admin_plan_edit(pid):
    category=request.form.get("category","Other").strip() or "Other"
    stock=int(request.form.get("stock",0))
    stock_status=1 if request.form.get("stock_status")=="1" else 0
    q("""UPDATE plans SET name=?,category=?,description=?,ram=?,cpu=?,storage=?,price=?,billing_period=?,
         image=?,stock=?,stock_status=? WHERE id=?""",
      (request.form["name"],category,request.form.get("description",""),request.form.get("ram",""),
       request.form.get("cpu",""),request.form.get("storage",""),float(request.form["price"]),
       request.form.get("billing_period","month"),request.form.get("image",""),stock,stock_status,pid))
    log(f"Admin edited plan {pid}",current_user()["id"]); flash("Plan updated.","success")
    return redirect(url_for("admin_plans"))

@app.route("/admin/plan/<int:pid>/toggle",methods=["POST"])
@admin_required
def admin_plan_toggle(pid):
    q("UPDATE plans SET active=1-active WHERE id=?",(pid,)); log(f"Toggled plan {pid}",current_user()["id"]); return redirect(url_for("admin_plans"))

@app.route("/admin/plan/<int:pid>/delete",methods=["POST"])
@admin_required
def admin_plan_delete(pid):
    q("DELETE FROM plans WHERE id=?",(pid,)); log(f"Deleted plan {pid}",current_user()["id"]); return redirect(url_for("admin_plans"))

@app.route("/admin/vps-verifications",methods=["GET","POST"])
@admin_required
def admin_vps_verifications():
    if request.method=="POST":
        vid=int(request.form["verification_id"]); status=request.form.get("status","Pending")
        q("UPDATE vps_verifications SET status=?,admin_note=?,updated_at=? WHERE id=?",(status,request.form.get("admin_note","").strip(),now(),vid))
        v=q("SELECT * FROM vps_verifications WHERE id=?",(vid,),True)
        if v: notify(v["user_id"],"VPS Verification Updated",f"Your VPS verification is now {status}.","Info")
        flash("VPS verification updated.","success")
    rows=q("SELECT v.*,u.username,u.email,p.name plan_name FROM vps_verifications v JOIN users u ON u.id=v.user_id JOIN plans p ON p.id=v.plan_id ORDER BY v.id DESC")
    return render_template("admin/vps_verifications.html",verifications=rows)

@app.route("/admin/orders",methods=["GET","POST"])
@admin_required
def admin_orders():
    if request.method=="POST":
        oid=int(request.form["order_id"]); ps=request.form.get("payment_status"); osx=request.form.get("order_status")
        q("UPDATE orders SET payment_status=?,order_status=? WHERE id=?",(ps,osx,oid))
        o=q("SELECT * FROM orders WHERE id=?",(oid,),True)
        q("UPDATE payments SET status=? WHERE order_id=?",(ps,oid))
        if ps=="Paid": q("INSERT OR IGNORE INTO invoices(invoice_code,order_id,created_at) VALUES(?,?,?)",(f"INV-{o['order_code']}",oid,now()))
        notify(o["user_id"],"Order Updated",f"Order #{o['order_code']}: {osx}.","Info"); log(f"Updated order #{o['order_code']}",current_user()["id"]); flash("Order updated.","success")
    rows=q("""SELECT o.*,u.username,p.name plan_name FROM orders o JOIN users u ON u.id=o.user_id JOIN plans p ON p.id=o.plan_id ORDER BY o.id DESC""")
    return render_template("admin/orders.html",orders=rows)

@app.route("/admin/redeem",methods=["GET","POST"])
@admin_required
def admin_redeem():
    if request.method=="POST":
        expiry=request.form.get("expiry") or None
        q("""INSERT INTO redeem_codes(code,reward_type,value,max_uses,per_user_limit,expiry,applicable_product,active,created_at)
             VALUES(?,?,?,?,?,?,?,?,?)""",(request.form["code"].strip().upper(),request.form["reward_type"],float(request.form["value"]),
             int(request.form.get("max_uses",1)),int(request.form.get("per_user_limit",1)),expiry,request.form.get("applicable_product",""),1,now()))
        log("Admin created redeem code",current_user()["id"]); flash("Redeem code created.","success")
    return render_template("admin/redeem.html",codes=q("SELECT * FROM redeem_codes ORDER BY id DESC"))

@app.route("/admin/redeem/<int:cid>/toggle",methods=["POST"])
@admin_required
def admin_redeem_toggle(cid):
    q("UPDATE redeem_codes SET active=1-active WHERE id=?",(cid,)); return redirect(url_for("admin_redeem"))

@app.route("/admin/tickets")
@admin_required
def admin_tickets():
    rows=q("""SELECT t.*,u.username FROM tickets t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC""")
    return render_template("admin/tickets.html",tickets=rows)

@app.route("/admin/ticket/<int:tid>",methods=["GET","POST"])
@admin_required
def admin_ticket(tid):
    t=q("SELECT * FROM tickets WHERE id=?",(tid,),True)
    if not t: abort(404)
    if request.method=="POST":
        status=request.form.get("status",t["status"]); priority=request.form.get("priority",t["priority"])
        q("UPDATE tickets SET status=?,priority=?,internal_note=?,updated_at=? WHERE id=?",(status,priority,request.form.get("internal_note",""),now(),tid))
        if request.form.get("message"):
            q("INSERT INTO ticket_messages(ticket_id,user_id,message,created_at) VALUES(?,?,?,?)",(tid,current_user()["id"],request.form["message"],now()))
            notify(t["user_id"],"Support Reply",f"Admin replied to {t['ticket_code']}.","Info")
        flash("Ticket updated.","success")
    return render_template("admin/ticket.html",ticket=t,messages=q("""SELECT m.*,u.username,u.is_admin FROM ticket_messages m JOIN users u ON u.id=m.user_id WHERE m.ticket_id=? ORDER BY m.id""",(tid,)))

@app.route("/admin/announcements",methods=["GET","POST"])
@admin_required
def admin_announcements():
    if request.method=="POST":
        q("INSERT INTO announcements(title,message,type,active,created_at) VALUES(?,?,?,?,?)",(request.form["title"],request.form["message"],request.form["type"],1,now()))
        flash("Announcement published.","success")
    return render_template("admin/announcements.html",announcements=q("SELECT * FROM announcements ORDER BY id DESC"))

@app.route("/admin/settings",methods=["GET","POST"])
@admin_required
def admin_settings():
    keys = ["upi_id","upi_qr","brand_logo",
            "discord_client_id","discord_client_secret","discord_redirect_uri",
            "google_client_id","google_client_secret","google_redirect_uri"]
    if request.method=="POST":
        for key in keys:
            if key in request.form:
                set_setting(key, request.form.get(key,"").strip())
        flash("Settings saved.","success")
        log("Admin updated platform settings",current_user()["id"])
    values={k:setting(k) for k in keys}
    return render_template("admin/settings.html",settings=values)

@app.route("/admin/logs")
@admin_required
def admin_logs():
    return render_template("admin/logs.html",logs=q("""SELECT l.*,u.username FROM activity_logs l LEFT JOIN users u ON u.id=l.actor_id ORDER BY l.id DESC LIMIT 300"""))

@app.errorhandler(403)
def e403(e): return render_template("error.html",code=403,title="Access denied",message="You do not have permission to view this page."),403
@app.errorhandler(404)
def e404(e): return render_template("error.html",code=404,title="Oops! This page doesn't exist.",message="The page you requested could not be found."),404
@app.errorhandler(413)
def e413(e): return render_template("error.html",code=413,title="File too large",message="Maximum upload size is 8 MB."),413
@app.errorhandler(500)
def e500(e): return render_template("error.html",code=500,title="Something went wrong",message="Please try again or contact support."),500

init_db()

if __name__ == "__main__":
    print("PrimeCloud Billing Platform")
    print("Running on http://0.0.0.0:4040")
    app.run(host="0.0.0.0", port=4040)
